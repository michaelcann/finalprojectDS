import joblib

modelLR = joblib.load('modelJoblib')

#'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term', 
# 'Credit_History', 'Gender_Male',  'Married_Yes', 'Dependents_1', 'Dependents_2', 'Dependents_3+', 
# 'Education_Not Graduate','Self_Employed_Yes','Property_Area_Semiurban','Property_Area_Urban'
print(modelLR.predict([[2500, 2500, 90, 60, 1.0,1,1,0,0,0,0,0,1,0]]))