from flask import Flask, render_template, request, session, redirect
import pandas as pd 
import csv
import plotly
import numpy as np

from matplotlib.figure import Figure

import io
import pandas as pd
import seaborn as sns

from sklearn.model_selection import train_test_split

from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

from sklearn.linear_model import LogisticRegression



app = Flask(__name__)

loanData = pd.read_csv('./static/madfhantr.csv')
@app.route("/")
def home():
  return render_template("home.html")

@app.route('/dataset', methods = ("POST", "GET"))
def html_table():
    return render_template("dataset.html", tables =[loanData.to_html(classes = 'data', header = "true")])