import pandas as pd 
import csv
import numpy as np

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

import joblib

loanData = pd.read_csv('./static/madfhantr.csv')

# print(loanData.head())

## Clean Data
##INPUT GENDER NULL VALUE
loanData['Gender'] = loanData['Gender'].fillna('Male')

##INPUT MARRIED NULL VALUE
Married1 = 'Yes'
Married2 = 'No'


locMarried1 = loanData[(loanData['CoapplicantIncome'] > 0) & (loanData['Married'].isna() == True)]['Married'].index
locMarried2 = loanData[(loanData['CoapplicantIncome'] == 0) & (loanData['Married'].isna() == True)]['Married'].index


loanData['Married'].iloc[locMarried1] = loanData['Married'].iloc[locMarried1].fillna(Married1)
loanData['Married'].iloc[locMarried2] = loanData['Married'].iloc[locMarried2].fillna(Married2)


pd.set_option('display.max_rows', None)

##INPUT DEPENDENTS NULL VALUE
Dependent0 = '0'
Dependent1 = '1'
Dependent2 = '2'
Dependent3 = '3+'

locDependent0 = loanData[(loanData['ApplicantIncome'] <= 2877.500000) & (loanData['Dependents'].isna() == True)]['Dependents'].index
locDependent1 = loanData[((loanData['ApplicantIncome'] > 2877.500000) & (loanData['ApplicantIncome'] <= 3812.500000)) & (loanData['Dependents'].isna() == True)]['Dependents'].index
locDependent2 = loanData[((loanData['ApplicantIncome'] > 3812.500000) & (loanData['ApplicantIncome'] <= 5795.000000)) & (loanData['Dependents'].isna() == True)]['Dependents'].index
locDependent3 = loanData[(loanData['ApplicantIncome'] > 5795.000000) & (loanData['Dependents'].isna() == True)]['Dependents'].index

loanData['Dependents'].iloc[locDependent0] = loanData['Dependents'].iloc[locDependent0].fillna(Dependent0)
loanData['Dependents'].iloc[locDependent1] = loanData['Dependents'].iloc[locDependent1].fillna(Dependent1)
loanData['Dependents'].iloc[locDependent2] = loanData['Dependents'].iloc[locDependent2].fillna(Dependent2)
loanData['Dependents'].iloc[locDependent3] = loanData['Dependents'].iloc[locDependent3].fillna(Dependent3)

pd.set_option('display.max_rows', None)

##INPUT SELF EMPLOYED NULL VALUE
loanData['Self_Employed'] = loanData['Self_Employed'].fillna('No')

##INPUT LOAN AMOUNT NULL VALUE
loan1 = loanData[loanData['ApplicantIncome'] <= 2877.500000].describe()['LoanAmount']['25%']
loan2 = loanData[(loanData['ApplicantIncome'] > 2877.500000) & (loanData['ApplicantIncome'] <= 3812.500000)].describe()['LoanAmount']['50%']
loan3 = loanData[(loanData['ApplicantIncome'] > 3812.500000) & (loanData['ApplicantIncome'] <= 5795.000000 )].describe()['LoanAmount']['75%']
loan4 = loanData[loanData['ApplicantIncome'] > 5795.000000 ].describe()['LoanAmount']['max']

locLoan1 = loanData[(loanData['ApplicantIncome'] <= 2877.500000) & (loanData['LoanAmount'].isna() == True)]['LoanAmount'].index
locLoan2 = loanData[((loanData['ApplicantIncome'] > 2877.500000) & (loanData['ApplicantIncome'] <= 3812.500000)) & (loanData['LoanAmount'].isna() == True)]['LoanAmount'].index
locLoan3 = loanData[((loanData['ApplicantIncome'] > 3812.500000) & (loanData['ApplicantIncome'] <= 5795.000000)) & (loanData['LoanAmount'].isna() == True)]['LoanAmount'].index
locLoan4 = loanData[(loanData['ApplicantIncome'] > 5795.000000) & (loanData['LoanAmount'].isna() == True)]['LoanAmount'].index

loanData['LoanAmount'].iloc[locLoan1] = loanData['LoanAmount'].iloc[locLoan1].fillna(loan1)
loanData['LoanAmount'].iloc[locLoan2] = loanData['LoanAmount'].iloc[locLoan2].fillna(loan2)
loanData['LoanAmount'].iloc[locLoan3] = loanData['LoanAmount'].iloc[locLoan3].fillna(loan3)
loanData['LoanAmount'].iloc[locLoan4] = loanData['LoanAmount'].iloc[locLoan4].fillna(loan4)

pd.set_option('display.max_rows', None)

##INPUT LOAN AMOUNT TERM NULL VALUE
loanData['Loan_Amount_Term'] = loanData['Loan_Amount_Term'].fillna(360.0)

##INPUT CREDIT HISTORY NULL VALUE
History1 = 1.0
History2 = 0.0


locHistory1 = loanData[(loanData['Loan_Status'] == 'Y') & (loanData['Credit_History'].isna() == True)]['Credit_History'].index
locHistory2 = loanData[(loanData['Loan_Status'] == 'N') & (loanData['Credit_History'].isna() == True)]['Credit_History'].index


loanData['Credit_History'].iloc[locHistory1] = loanData['Credit_History'].iloc[locHistory1].fillna(History1)
loanData['Credit_History'].iloc[locHistory2] = loanData['Credit_History'].iloc[locHistory2].fillna(History2)


pd.set_option('display.max_rows', None)

# print(loanData.isna().sum())

# ##BUILD DUMMIES
loanData.drop(["Loan_ID"], axis=1, inplace=True)
loanData_dummies = pd.get_dummies(loanData,drop_first=True) ## Encoding categrical Features

# ##SPLITING DATASET
# x = loanData.drop(['Loan_Status'], axis = 1)
# y = loanData['Loan_Status']

loanData_dummies['Loan_Status_Y'] = ["Approved" if each == 1 else "Not Approved" for each in loanData_dummies.Loan_Status_Y]

# loanData = loanData.drop(['Loan_Status_Y'], axis=1)
# loanData = loanData.drop(['Loan_Status_'], axis=1)
# loanData_dummies = loanData_dummies.drop(['Loan_Status_'], axis=1)


x_train, x_test, y_train, y_test = train_test_split(
  loanData_dummies[['ApplicantIncome', 'CoapplicantIncome', 'LoanAmount', 'Loan_Amount_Term', 'Credit_History', 'Gender_Male',  'Married_Yes', 'Dependents_1', 'Dependents_2', 'Dependents_3+', 'Education_Not Graduate','Self_Employed_Yes','Property_Area_Semiurban','Property_Area_Urban']],
  loanData_dummies['Loan_Status_Y'],test_size = 0.2,random_state=0)

modelLR = LogisticRegression(solver='newton-cg', multi_class =  'auto', max_iter = 1000)
modelLR.fit(x_train, y_train)

joblib.dump(modelLR, 'modelJoblib')

print(loanData_dummies)




