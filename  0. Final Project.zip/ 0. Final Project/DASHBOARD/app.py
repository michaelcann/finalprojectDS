from flask import Flask, render_template, request, session, redirect
import pandas as pd 
import csv
import plotly
import numpy as np
import plotly
import plotly.plotly as py
import plotly.graph_objs as go

from matplotlib.figure import Figure

import io
import pandas as pd
import seaborn as sns

from sklearn.model_selection import train_test_split

from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

from flask import Flask, make_response
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas



app = Flask(__name__)

loanData = pd.read_csv('./static/madfhantr.csv')
@app.route("/")
def home():
  return render_template("home.html")

@app.route('/dataset', methods = ("POST", "GET"))
def html_table():
    return render_template("dataset.html", tables =[loanData.to_html(classes = 'data', header = "true")])

@app.route("/visual")
def visual():
    count = 500
    xScale = np.linspace(0, 100, count)
    yScale = np.random.randn(count)
 
    # Create a trace
    trace = go.Scatter(
        x = xScale,
        y = yScale
    )
 
    data = [trace]
    graphJSON = json.dumps(data, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('visual.html',
                               graphJSON=graphJSON)

@app.route('/plot.png')
def plot():
    fig = Figure()
    axis = fig.add_subplot(1, 1, 1)

    xs = range(100)
    ys = [random.randint(1, 50) for x in xs]

    axis.plot(xs, ys)
    canvas = FigureCanvas(fig)
    output = io.BytesIO()
    canvas.print_png(output)
    response = make_response(output.getvalue())
    response.mimetype = 'image/png'
    return response

# @app.route('/bar')
# def bar():
#     print(loanData.columns)
#     sns.countplot(x="Loan_Status", data=loanData, palette="bwr")
#     graph_export = 
#     return render_template("bar.html", le_graph = graph_export)


# @app.route("/2d")
# @cross_origin()
# def twod():
#     x = request.args.get('x')
#     y = request.args.get('y')
#     requiredDf = loanData[[x,y]].copy()
#     requiredDf.columns=["dimensions","measure"]
#     json = requiredDf.to_json(orient='records')
#     return json

if __name__ == "__main__":
  app.run(debug = True)