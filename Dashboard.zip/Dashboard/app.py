from flask import Flask, render_template, request, session, redirect
import pandas as pd 
import csv
import plotly
import numpy as np

from matplotlib.figure import Figure

import io
import pandas as pd
import seaborn as sns

from sklearn.model_selection import train_test_split

from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

from sklearn.linear_model import LogisticRegression
import joblib



app = Flask(__name__)

loanData = pd.read_csv('./static/madfhantr.csv')
@app.route("/")
def home():
  return render_template("home.html")

@app.route('/predict', methods = ("POST", "GET"))
def predict():
  if request.method ==  "POST":
    input = request.form
    prediksi = modelLR.predict([[float(input['ApplicantIncome']), int(input['CoapplicantIncome']), float(input['LoanAmount']), 
    float(input['Loan_Amount_Term']), float(input['Credit_History']), float(input['Gender_Male']),  float(input['Married_Yes']), 
    float(input['Dependents_1']), float(input['Dependents_2']), float(input['Dependents_3+']), float(input['Education_Not Graduate']),
    float(input['Self_Employed_Yes']),float(input['Property_Area_Semiurban']),float(input['Property_Area_Urban'])]])
    return render_template("predict.html", data = input, pred = prediksi)


@app.route('/dataset', methods = ("POST", "GET"))
def html_table():
    return render_template("dataset.html", tables =[loanData.to_html(classes = 'data', header = "true")])

@app.route("/visual")
def visual():
    count = 500
    xScale = np.linspace(0, 100, count)
    yScale = np.random.randn(count)
 
    data = loanData
    return render_template('visual.html')

# @app.route('/bar')
# def bar():
#     print(loanData.columns)
#     sns.countplot(x="Loan_Status", data=loanData, palette="bwr")
#     graph_export = 
#     return render_template("bar.html", le_graph = graph_export)


# @app.route("/2d")
# @cross_origin()
# def twod():
#     x = request.args.get('x')
#     y = request.args.get('y')
#     requiredDf = loanData[[x,y]].copy()
#     requiredDf.columns=["dimensions","measure"]
#     json = requiredDf.to_json(orient='records')
#     return json

if __name__ == "__main__":
  modelLR = joblib.load('modelJoblib')
  app.run(debug = True)

